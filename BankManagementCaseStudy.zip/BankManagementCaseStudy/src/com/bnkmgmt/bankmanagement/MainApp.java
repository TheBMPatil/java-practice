package com.bnkmgmt.bankmanagement;

import com.bnkmgmt.finixbank.FinixBank;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinixBank.StartBank();
		System.out.println("GoodBye");
		return;
	}

}
